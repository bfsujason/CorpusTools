rm(list=ls(all=T))
data <- read.table(file=choose.files(caption="Please choose the file containing cluster features"), header=T, sep="\t", quote="" )
data.t <- t(data)
colnames(data.t) = data.t[1,]
data.t <- data.t[-1,]
data.t <- data.frame(data.t)
data.t <- transform(data.t, fucking=as.numeric(as.character(fucking)), so=as.numeric(as.character(so)),
pretty=as.numeric(as.character(pretty)), very=as.numeric(as.character(very)),
really=as.numeric(as.character(really)), fairly=as.numeric(as.character(fairly)))

data.t.norm <- data.frame(scale(data.t))
data.t.norm <- data.frame(t(data.t.norm))
d <- dist(data.t.norm)
model <- hclust(d, method="ward")
plot(model)

