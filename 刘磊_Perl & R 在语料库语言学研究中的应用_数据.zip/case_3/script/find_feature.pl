#!/usr/bin/perl

use strict;
use warnings;

print "Please type in the name of source directory (e.g. C:/conv): ";
my $source_dir = <STDIN>;
chomp($source_dir);
print "Please type in the name of taget file (e.g. C:/Cluster_Feature.txt): ";
my $target_file = <STDIN>;
chomp($target_file);

opendir DIR, $source_dir or die "Cannot open the directory: $!";
open OUT, ">", $target_file or die "Cannot open the file: $!";

print OUT "node", "\t";

my %col_of_amplif;
my %type_of_col;

while ( my $filename = readdir DIR ) {
	next if ( $filename =~ /^\./ );
	open IN, "<", "$source_dir/$filename" or die "Cannot open the file: $!";
	while ( <IN> ) {
		while ( /<w AV0>(so|very|really|fucking|fairly|pretty)\s+<w AJ0>(\w+)/ig ) {
            my $node = lc($1);
			my $col = lc($2);
			$col_of_amplif{$node}{$col}++;
			$type_of_col{$col}++;
		}
	}
}

my @col_type = keys %type_of_col;

foreach my $item ( @col_type ) {
	print OUT $item, "\t";
}

print OUT "\n";

foreach my $item ( keys %col_of_amplif ) {
	print OUT $item, "\t";
	foreach my $type ( @col_type ) {
		if ( $col_of_amplif{$item}{$type} ) {
			print OUT  $col_of_amplif{$item}{$type}, "\t";
		} else {
			print OUT '0', "\t";
		}
	}
    print OUT "\n";
}