#!/usr/bin/perl

################################################################
#  
#  This script is written to extract N-grams from given
#  texts with N specified by the user at commmand line.
#  The output N-gram files will be sorted according to
#  frequencies in decreasing order. Please note I use
#  BNC-world Edition as test corpus.
#
#  Usage:
#
#       perl find_ngram.pl span source_dir target_file
#
#  Example:
#
#       perl find_ngram.pl 4 WA WA_4gram.txt
#
#  Please Contact me if you find any bugs:
#
#       bfsujason@163.com
#
################################################################


use strict;
use warnings;
use File::Find; # �����ļ���
use Cwd; # ���ص�ǰ�ļ�����

print "Please type in the name of source directory (e.g. C:/WA): ";
my $dir = <STDIN>;
chomp($dir);
my @dir = $dir;
print "Please type in the length of ngram (e.g. 5): ";
my $span = <STDIN>;
chomp($span);
print "Please type in the name of taget file (e.g. C:/WA_5_gram.txt): ";
my $target_file = <STDIN>;
chomp($target_file);

my %letter_of_numbers;
my %freq_of_clusters;
my $counter;

@letter_of_numbers{(1..26)} = ('A'..'Z');

open OUT, ">", $target_file or die "Cannnot open the file: $!";
print OUT join "\t",@letter_of_numbers{ (1..4) },'Freq','Range';
print OUT "\n";

find(\&wanted, @dir);

foreach my $item ( sort { $freq_of_clusters{$b}->[0] <=> $freq_of_clusters{$a}->[0] } keys %freq_of_clusters) {
	my $item_cp = $item;
    $item_cp =~ s/\s/\t/g;
	print OUT $item_cp, "\t", $freq_of_clusters{$item}->[0], "\t", $#{$freq_of_clusters{$item}},"\n";
}

sub wanted {
	if ( -f ) {
		$counter++;
		my $dir = cwd();
		my $filename = "$dir/$_";
		open IN, "<", $filename or die "Cannot open the file: $!";
	        while ( <IN> ) {
		       &stats;
	        }
	}
}

sub stats {
	$_ = lc($_);
	if ( /^<s/ ) {
		my @sent = $_ =~ /<w .+?>(.+?)[ <\n]/g;
		my $len = $#sent + 1;
		    if ( $len >= $span ) {
				my $range = $len - $span;
				foreach my $index ( 0 .. $range ) {
					my $new = join " ", @sent[$index .. $index+$span-1];
					$freq_of_clusters{$new}->[0]++;
					if ( ! $freq_of_clusters{$new}->[1] || $freq_of_clusters{$new}->[-1] != $counter ) {
						push $freq_of_clusters{$new}, $counter;
					}
				}
		    }				
	}
}
