#!/usr/bin/perl

###############################################################
#
#  This script is written to extract the files matching
#  the BNC Indexer criteria from BNC-world Edition.
#  To achieve this goal, you need to copy the file names
#  into a file called file_name.txt.
#
#   Please contact me if you find any bugs:
#
#     bfsujason@163.com
#
###############################################################


use strict;
use warnings;
use File::Find;
use File::Copy;
use File::Basename;
use Cwd;

print "Please type in the name of file_list: ";
my $file_name = <STDIN>;
chomp($file_name);

print "Please enter the name of source directory: ";
my $source = <STDIN>;
chomp($source);
my @source_dir = $source;

print "Please enter the name of target directory: ";
my $des_dir = <STDIN>;
chomp($des_dir);
my $dir = cwd();
$des_dir = "$dir/$des_dir/";

my @file_names;

open IN, "<", $file_name or die "Cannot open the file: $!";

while ( <IN> ) {
    chomp;
    push @file_names, $_;
}

find sub { ! -d && (grep $_ eq basename($File::Find::name), @file_names) && copy("./" . basename($File::Find::name), $des_dir . basename($File::Find::name))}, @source_dir ;
