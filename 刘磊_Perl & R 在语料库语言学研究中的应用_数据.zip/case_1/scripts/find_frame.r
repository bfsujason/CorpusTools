
######################################################
#  
#  This script is written to extract p-frames
#  from n-gram files. The result includs 
#  the token and type nmuber of each p-frame
#  and their interal variants.
#
#   Usage:
#
#      In the R GUI, choose �ļ� --������R�ű��ļ�
#
#   Please contact me if you find any bugs:
#   
#       bfsujason@163.com
#
######################################################


rm(list=ls(all=T))

cat("Please enter the length of Ngram (N >= 3):\n")
span <- scan(n=1,what=numeric())

fields.all <- LETTERS[1:span]

if (span > 3) {
    fields.part <- combn(fields.all[2:(span-1)],span-3)
    frame.list <- strsplit(paste(fields.all[1],apply(fields.part,2,paste,collapse=" "),fields.all[span]), " ") 
} else {
    frame.list <- strsplit(paste(fields.all[1],fields.all[span])," ")
}

input <- choose.files(caption="Please choose the file containing ngrams")
output.1 <- choose.files(caption="Please choose the file for saving p-frames")
data <- read.table(input,header=T,sep="\t",quote="")
data <- subset(data, subset=(Range >= 5))
lst <- list()
i <- 0

find_frame_info <- function(y) {

    fun <- function(x) {
        record <- x[y]
	index <- which(fields.all==fields.all[!fields.all %in% y])
	slot <- x[index]
	freq <- x['Freq']
	names(freq) <- slot
	record <- append( record, after=index - 1, "*" )
	record <- paste(record,collapse=" ")
        if (is.null(lst[[record]]['TOTAL']) ) {
            lst[[record]]['TOKEN'] <<- freq
	    lst[[record]]['TYPE'] <<- 1
	    lst[[record]]['VARIETY'] <<- paste(y,collapse=" ")
         }  else {
            lst[[record]]['TOKEN'] <<- as.numeric(lst[[record]]['TOKEN']) + as.numeric(freq)
	    lst[[record]]['TYPE'] <<- as.numeric(lst[[record]]['TYPE']) + 1
         }
	 lst[[record]] <<- c(lst[[record]], freq)
     }

    apply(data,1,fun)
}

output_format <- function(x) {
    i <<- i + 1
    cat(file=output.1, names(lst.1[i]), "\n", append=T)
    cat(file=output.1,paste(names(x),x,collapse="\n"),"\n\n",append=T)
}

sapply(frame.list, find_frame_info)

vec <- unlist(lst)

index.1 <- grep("TOKEN$",names(vec),perl=T)
lst.1 <- lst[order(-as.numeric(vec[index.1]),names(vec[index.1]))]

sapply(lst.1, output_format)
