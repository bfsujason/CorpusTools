rm(list=ls(all=T))
data <- read.table(file=choose.files(),header=T,sep="\t",quote="")
fiction.active = subset(data, subset=(Genre=='fiction' & Voice == 'active'))
fiction.passive = subset(data, subset=(Genre=='fiction' & Voice == 'passive'))
fiction.active.verb.freq <- sort(table(as.character(fiction.active$Verb)),decreasing=T)
fiction.passive.verb.freq <- sort(table(as.character(fiction.passive$Verb)),decreasing=T)
head(fiction.active.verb.freq,10)
head(fiction.passive.verb.freq,10)

