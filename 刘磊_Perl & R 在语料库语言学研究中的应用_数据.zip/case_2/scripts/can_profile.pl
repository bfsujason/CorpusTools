#!/usr/bin/perl

use strict;
use warnings;
use File::Find;
use Cwd;
use XML::LibXML;

print "Please type in the name of source directory (e.g. C:/crown): ";
my $dir = <STDIN>;
chomp($dir);
my @dir = $dir;
print "Please type in the name of taget file (e.g. C:/Can_Profile.txt): ";
my $target_file = <STDIN>;
chomp($target_file);

my $parser = XML::LibXML->new;
my %record_of_can;

open OUT, ">", $target_file or die "Cannnot open the file: $!";
print OUT 'Genre', "\t", 'Voice', "\t", "Verb", "\n";

find(\&wanted, @dir);

sub wanted {
	if ( -f ) {
		my ($genre) = $_ =~ /^(\w)/;
		if ( $genre =~ /A|B|C/ ) {
			$genre = "press";
		} elsif ( $genre =~ /D|E|F|G|H/ ) {
			$genre = "prose";
	    } elsif ( $genre =~ /J/ ) {
			$genre = "learned";
        } else {
			$genre = "fiction";
		}
		my $dir = cwd();
		my $filename = "$dir/$_";
	    my $doc = $parser->parse_file("$filename");
		my @active_nodes = $doc->findnodes("//SQ/MD[text()='can' or text()='Can' or text()='ca' or text()='Ca']/../VP/VB |
		                             //VP/MD[text()='can' or text()='Can' or text()='ca' or text()='Ca']/../VP/VB/parent::node()[not(VP)]/VB |
									 //VP/MD[text()='can' or text()='Can' or text()='ca' or text()='Ca']/../VP/VB/../VP/VBG |
								     //VP/MD[text()='can' or text()='Can' or text()='ca' or text()='Ca']/../VP/child::VP[position()=1 or position()=2 or position()=3 or position()=4]/VB"
		                            );
		my @passive_nodes = $doc->findnodes("//VP/MD[text()='can' or text()='Can' or text()='ca' or text()='Ca']/../VP/VB[text()='be' or text='get']/../VP/VBN/parent::node()[not(VP)]/VBN");
		                                  
		foreach my $node ( @active_nodes ) {
		   $record_of_can{$genre}{"active"}++;
		   print OUT $genre, "\t", "active", "\t", $node->find("."), "\n";
		}
		foreach my $node ( @passive_nodes ) {
		   $record_of_can{$genre}{"passive"}++;
		    print OUT $genre, "\t", "passive", "\t", $node->find("."), "\n";
		}
	}		
}

